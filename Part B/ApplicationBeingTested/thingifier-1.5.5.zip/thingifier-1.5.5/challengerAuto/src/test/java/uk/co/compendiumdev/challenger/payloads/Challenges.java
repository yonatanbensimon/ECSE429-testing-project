package uk.co.compendiumdev.challenger.payloads;

import uk.co.compendiumdev.challenger.payloads.Challenge;

import java.util.List;

public class Challenges {
    public List<Challenge> challenges;
}
