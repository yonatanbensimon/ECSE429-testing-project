package uk.co.compendiumdev.thingifier.core.domain.datapopulator;

import uk.co.compendiumdev.thingifier.core.EntityRelModel;

public interface DataPopulator {

    void populate(EntityRelModel model);
}
