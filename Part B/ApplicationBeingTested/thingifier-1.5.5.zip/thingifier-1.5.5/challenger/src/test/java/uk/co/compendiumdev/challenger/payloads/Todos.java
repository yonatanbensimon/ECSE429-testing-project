package uk.co.compendiumdev.challenger.payloads;

import java.util.List;

public class Todos {
    public List<Todo> todos;
}
