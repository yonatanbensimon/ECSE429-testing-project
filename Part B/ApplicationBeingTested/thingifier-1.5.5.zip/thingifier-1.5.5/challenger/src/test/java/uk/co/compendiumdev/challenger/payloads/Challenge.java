package uk.co.compendiumdev.challenger.payloads;

public class Challenge {
    public String name;
    public String description;
    public boolean status;
}
