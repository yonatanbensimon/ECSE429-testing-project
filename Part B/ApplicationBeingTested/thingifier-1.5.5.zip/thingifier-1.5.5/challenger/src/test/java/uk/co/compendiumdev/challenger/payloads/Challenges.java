package uk.co.compendiumdev.challenger.payloads;

import java.util.List;

public class Challenges {
    public List<Challenge> challenges;
}
