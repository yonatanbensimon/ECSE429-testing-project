package uk.co.compendiumdev.challenger.payloads;

public class Todo {

    public Integer id;
    public String title;
    public String description;
    public Boolean doneStatus;
}
