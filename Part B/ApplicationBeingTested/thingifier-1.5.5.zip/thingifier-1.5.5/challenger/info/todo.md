- [Welcome - Overview](00_welcome.md)

Multi-User

- [How to Register on the Cloud](10_how_to_register_cloud_challenger.md)

Single-Player

- [How to download and run single player mode](20_how_to_download_run_single_player.md)

Technology

- What is...?


## Tooling - Insomnia

- general tooling tips and videos
    - create a workspace
    - environment variables
- How to Solve with Insomnia
    - [POST Challenger 201](how-to/post_challenger_201.md)
        
- how to solve challenge X with tool X

## Tooling - Postman

## Tooling - etc.

## Challenge Debriefs

Debrief of challenge:

- [POST Challenger 201](debrief/post_challenger_201.md)
- Debrief of challenge X

## Automating

- with library X ...