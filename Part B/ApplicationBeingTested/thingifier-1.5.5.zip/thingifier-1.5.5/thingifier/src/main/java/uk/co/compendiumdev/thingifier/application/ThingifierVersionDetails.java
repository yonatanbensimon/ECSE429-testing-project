package uk.co.compendiumdev.thingifier.application;

public class ThingifierVersionDetails {

    final public static String VERSION_NUMBER = "1.5";

    final public static String COPYRIGHT_YEAR = "2020";
}
