package uk.co.compendiumdev.thingifier.api.routings;

public enum RoutingVerb {
    GET, HEAD, DELETE, PATCH, PUT, OPTIONS, POST;
}
